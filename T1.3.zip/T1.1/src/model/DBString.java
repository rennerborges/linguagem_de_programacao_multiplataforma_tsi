/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author renner
 */
public class DBString {
    public static final String URL = "jdbc:postgresql://localhost:5432/LPM";
    public static final String USER = "postgres";
    public static final String PASSWORD = "postgres";
    public static final String DRIVER = "org.postgresql.Driver";
}
