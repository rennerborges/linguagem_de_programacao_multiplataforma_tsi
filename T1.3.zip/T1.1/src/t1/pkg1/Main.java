/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package t1.pkg1;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import t1.pkg1.controller.Endereco;
import t1.pkg1.controller.Telefone;
import t1.pkg1.controller.Cliente;
import t1.pkg1.controller.Fornecedor;
import t1.pkg1.controller.Produto;


import java.sql.*;
import java.text.SimpleDateFormat;
import model.BancoDados;
import model.CargoDAO;
import model.ClienteDAO;
import model.ClienteEnderecoDAO;
import model.ProdutoDAO;
import model.FornecedorDAO;
import model.FuncionarioDAO;


import java.util.Date;
import model.CompraDAO;
import model.CompraItemDAO;

import model.DBString;
import model.FinanceiroSaidaDAO;
import model.VendaDAO;
import t1.pkg1.controller.Cargo;
import t1.pkg1.controller.Compra;
import t1.pkg1.controller.Financeiro;
import t1.pkg1.controller.Item;
import t1.pkg1.controller.Funcionario;
import t1.pkg1.controller.Venda;
/**
 *
 * @author renner
 */
public class Main {

    /**
     * @param args the command line arguments
     * @throws java.sql.SQLException
     */
    public static void main(String[] args) throws SQLException {
        // TODO code application logic here

    }
    
}
